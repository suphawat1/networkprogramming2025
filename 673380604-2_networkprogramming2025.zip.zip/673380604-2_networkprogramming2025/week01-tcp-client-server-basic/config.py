# config.py
HOST = "127.0.0.1"  # loopback
PORT = 5000
BUFFER_SIZE = 1024
