#Step 0: Shared Configuration
# config.py
MULTICAST_GROUP = "224.1.1.1"
PORT = 8000
BUFFER_SIZE = 1024
TTL = 1  # restrict to local network
